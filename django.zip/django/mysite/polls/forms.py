from django import forms
from polls.models import Question
from polls.models import Topics


class AddTopic(forms.ModelForm):
    class Meta:
        module = Topics
        fields = '__all__'


class AddQuestion(forms.ModelForm):
    class Meta:
        module = Question
        fields = '__all__'
