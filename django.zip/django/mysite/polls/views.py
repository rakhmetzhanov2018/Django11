from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.template.loader import render_to_string

a = {
    'historyQ': render_to_string('123/historyQ.html'),
    'geographyQ': render_to_string('123/geographyQ.html'),
    'hq1': '''В каком году была подписана Декларация независимости США?
    1676
    1678
    1775
    1776''',
    'hq2': '''Каково было первоначальное название Нью-Йорка?
    Новый Амстердам
    Большое яблоко
    Имперский штат
    Готэм''',
    'hq3': '''Как долго длилась Столетняя война?
    116 лет
    100 лет
    50 лет'
    101 год''',
    'gq1': '''Высота горы Эверест составляет 29 029 футов. Но знаете ли вы, какая страна претендует на эту всемирно известную достопримечательность?
Колумбия
Непал
Швейцария
Венесуэла''',
    'gq2': '''Какая страна имеет аббревиатуру “CH”?
Китай
Швейцария
Куба
Чили''',
    'gq3': '''Какой самый большой остров в мире?
    Исландия
    Финляндия
    Гренландия
    Ирландия'''}


def main(request, address):
    data = {
        'n': address,
        'q': a[address].split('\n')[0],
        'qwe': [a[address].split('\n')[1], a[address].split('\n')[2], a[address].split('\n')[3],
                a[address].split('\n')[4]]
    }
    if a.get(address):
        if address[1] == 'q':
            return render(request, '123/question.html', context=data)
        return HttpResponse(a[address])
    return HttpResponseRedirect('404')


def info(request):
    return HttpResponse(render_to_string('123/info.html'))


def getNotFound(request):
    return HttpResponse(render_to_string('123/404.html'))
