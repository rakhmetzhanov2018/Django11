from django.http import HttpResponseRedirect, HttpResponse
from django.shortcuts import render, redirect
from django.template.loader import render_to_string

from polls.forms import AddTopic, AddQuestion

a = {
    'historyQ': render_to_string('123/historyQ.html'),
    'geographyQ': render_to_string('123/geographyQ.html'),
    'hq1': '''В каком году была подписана Декларация независимости США?
    1676
    1678
    1775
    1776
    4) 1776''',
    'hq2': '''Каково было первоначальное название Нью-Йорка?
    Новый Амстердам
    Большое яблоко
    Имперский штат
    Готэм
    1) Новый Амстердам''',
    'hq3': '''Как долго длилась Столетняя война?
    116 лет
    100 лет
    50 лет
    101 год
    1) 116 лет''',
    'gq1': '''Высота горы Эверест составляет 29 029 футов. Но знаете ли вы, какая страна претендует на эту всемирно известную достопримечательность?
Колумбия
Непал
Швейцария
Венесуэла
2) Непал''',
    'gq2': '''Какая страна имеет аббревиатуру “CH”?
Китай
Швейцария
Куба
Чили
2) Швейцария''',
    'gq3': '''Какой самый большой остров в мире?
    Исландия
    Финляндия
    Гренландия
    Ирландия
3) Гренландия'''}


def main(request, address):
    data = {
        'n': address,
        'q': a[address].split('\n')[0],
        'qwe': [a[address].split('\n')[1], a[address].split('\n')[2], a[address].split('\n')[3],
                a[address].split('\n')[4]],  # варианты ответов
        'ca': a[address].split('\n')[5]
    }
    if a.get(address):
        if address[1] == 'q':
            return render(request, '123/question.html', context=data)
        return HttpResponse(a[address])
    return HttpResponseRedirect('404')


def info(request):
    return HttpResponse(render_to_string('123/info.html'))


def getNotFound(request):
    return HttpResponse(render_to_string('123/404.html'))


def addT(request):
    if request.method == 'POST':
        form = AddTopic(request.POST)
    else:
        form = AddTopic()
    return render(request, '123/addT.html', {'form': form})


def addQ(request):
    if request.method == 'POST':
        form = addQ(request.POST)
        if form.is_valid():
            try:
                form.save()
            except:
                print('something went wrong')
    else:
        form = addQ()
    return render(request, '123/addQ.html', {'form': form})