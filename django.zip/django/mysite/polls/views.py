from django.http import HttpResponse, HttpResponseRedirect
from django.template.loader import render_to_string

a = {
    'info': render_to_string('123/info.html'),
    'historyQ': render_to_string('123/historyQ.html'),
    'hq1': 'Question 1</br>В каком году была подписана Декларация независимости США?</br>1)'
           '1676</br>2)1678</br>3)1775</br>4)1776',
    'hq2': 'Каково было первоначальное название Нью-Йорка?</br>1)Новый Амстердам</br>'
           '2)Большое яблоко</br>3)Имперский штат</br>4)Готэм',
    'hq3': 'Как долго длилась Столетняя война?</br>1)116 лет</br>2)100 лет</br>3)50 лет'
           '</br>4)101 год',
    'gq1': render_to_string('123/gq1.html'),
    'geographyQ': render_to_string('123/geographyQ.html'),
    'gq2': 'Какая страна имеет аббревиатуру “CH”?</br>1)Китай</br>2)Швейцария</br>3)'
           'Куба</br>4)Чили',
    'gq3': 'Какой самый большой остров в мире?</br>1)Исландия</br>2)Финляндия</br>3)'
           'Гренландия</br>4)Ирландия',
    'gq1Answer': 'Непал'}
b = True

def main(request, address):
    if a.get(address):
        return HttpResponse(a[address])
    return HttpResponseRedirect('404')


def getNotFound(request):
    return HttpResponse(render_to_string('123/404.html'))
