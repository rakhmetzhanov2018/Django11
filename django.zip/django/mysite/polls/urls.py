from django.urls import path
from . import views
from .views import addQ, addT

urlpatterns = [
    path('404', views.getNotFound),
    path('', views.info),
    path('<address>', views.main),
    path('addQ/', addQ, name='addQ'),
    path('addT/', addT, name='addT')

]
