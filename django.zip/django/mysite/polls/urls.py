from django.urls import path
"""frtgvhyujl"""
from . import views

urlpatterns = [
    path('404', views.getNotFound),
    path('info', views.info),
    path('<address>', views.main),

]
