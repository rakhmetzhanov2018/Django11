from django.urls import path
"""frtgvhyujl"""
from . import views

urlpatterns = [
    path('404', views.getNotFound),
    path('<address>', views.main)
]
