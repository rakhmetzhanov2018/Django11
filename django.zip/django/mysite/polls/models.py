from django.db import models


class Topics(models.Model):
    topics = models.CharField(max_length=20)


class Question(models.Model):
    name = models.CharField(max_length=20)
    topic = models.ForeignKey(Topics, on_delete=models.PROTECT)
    first_op = models.CharField(max_length=200)
    second_op = models.CharField(max_length=200)
    third_op = models.CharField(max_length=200)
    fourth_op = models.CharField(max_length=200)
    corr_op = models.CharField(max_length=200)
